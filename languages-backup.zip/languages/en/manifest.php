<?php return array(
  'package' => array(
    'type' => 'language',
    'name' => 'english',
    'version' => '5.0.1',
    'revision' => '$Revision$',
    'path' => 'application/languages/en',
    'repository' => 'socialengine.com',
    'title' => 'English',
    'author' => 'Webligo Developments',
    'license' => 'http://www.socialengine.com/license/',
    'directories' => array(
      'application/languages/en',
    )
  )
) ?>